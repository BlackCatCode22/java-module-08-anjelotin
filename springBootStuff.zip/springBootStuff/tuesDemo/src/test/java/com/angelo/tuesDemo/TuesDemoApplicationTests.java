package com.angelo.tuesDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TuesDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
