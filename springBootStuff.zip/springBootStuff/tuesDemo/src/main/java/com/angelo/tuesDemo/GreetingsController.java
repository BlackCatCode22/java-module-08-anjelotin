package com.angelo.tuesDemo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingsController {

    @RequestMapping("/greetings")
        public String getGreetings(){
        return "<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
                "    <title>Spring Boot Poem</title>\n" +
                "    <style>\n" +
                "        /* Reset some default browser styles */\n" +
                "        * {\n" +
                "            margin: 0;\n" +
                "            padding: 0;\n" +
                "            box-sizing: border-box;\n" +
                "        }\n" +
                "        \n" +
                "        /* Body styling */\n" +
                "        body {\n" +
                "            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;\n" +
                "            background-color: #f3f4f6;\n" +
                "            color: #333;\n" +
                "            text-align: center;\n" +
                "            padding: 50px;\n" +
                "            line-height: 1.6;\n" +
                "        }\n" +
                "\n" +
                "        /* Header styling */\n" +
                "        h1 {\n" +
                "            color: #2e8b57;\n" +
                "            font-size: 3em;\n" +
                "            margin-bottom: 20px;\n" +
                "            font-weight: 600;\n" +
                "        }\n" +
                "\n" +
                "        /* Poem container */\n" +
                "        .poem {\n" +
                "            background: linear-gradient(45deg, #ff6a00, #ff9e00, #f4a300);\n" +
                "            padding: 30px;\n" +
                "            border-radius: 12px;\n" +
                "            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.1);\n" +
                "            color: white;\n" +
                "            max-width: 800px;\n" +
                "            margin: 0 auto;\n" +
                "            font-size: 1.25em;\n" +
                "            font-weight: 500;\n" +
                "            overflow: hidden;\n" +
                "            position: relative;\n" +
                "        }\n" +
                "\n" +
                "        /* Floating gradient effect */\n" +
                "        .poem::before {\n" +
                "            content: \"\";\n" +
                "            position: absolute;\n" +
                "            top: 0;\n" +
                "            left: 0;\n" +
                "            right: 0;\n" +
                "            bottom: 0;\n" +
                "            background: linear-gradient(45deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.4));\n" +
                "            pointer-events: none;\n" +
                "            animation: gradientFlow 4s ease-in-out infinite;\n" +
                "        }\n" +
                "\n" +
                "        /* Key word highlight effect */\n" +
                "        .highlight {\n" +
                "            color: #ffdf00;\n" +
                "            font-style: italic;\n" +
                "            text-transform: uppercase;\n" +
                "            letter-spacing: 1px;\n" +
                "        }\n" +
                "\n" +
                "        /* Footer styling */\n" +
                "        .footer {\n" +
                "            margin-top: 50px;\n" +
                "            font-size: 1.2em;\n" +
                "            color: #8a2be2;\n" +
                "            font-weight: 500;\n" +
                "        }\n" +
                "\n" +
                "        /* Gradient flow animation */\n" +
                "        @keyframes gradientFlow {\n" +
                "            0% {\n" +
                "                background-position: -1000% 0%;\n" +
                "            }\n" +
                "            100% {\n" +
                "                background-position: 1000% 0%;\n" +
                "            }\n" +
                "        }\n" +
                "\n" +
                "        /* Responsive design */\n" +
                "        @media (max-width: 768px) {\n" +
                "            h1 {\n" +
                "                font-size: 2.5em;\n" +
                "            }\n" +
                "\n" +
                "            .poem {\n" +
                "                padding: 20px;\n" +
                "                font-size: 1.1em;\n" +
                "            }\n" +
                "        }\n" +
                "\n" +
                "        @media (max-width: 480px) {\n" +
                "            h1 {\n" +
                "                font-size: 2em;\n" +
                "            }\n" +
                "\n" +
                "            .poem {\n" +
                "                font-size: 1em;\n" +
                "                padding: 15px;\n" +
                "            }\n" +
                "\n" +
                "            .footer {\n" +
                "                font-size: 1em;\n" +
                "            }\n" +
                "        }\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "\n" +
                "    <h1>Spring Boot Poem</h1>\n" +
                "\n" +
                "    <div class=\"poem\">\n" +
                "        <p>\n" +
                "            With Spring Boot, the code takes flight,<br>\n" +
                "            We code in peace, we code in light.<br>\n" +
                "            Dependencies handled, all in line,<br>\n" +
                "            In restful paths, our routes define.<br>\n" +
                "        </p>\n" +
                "        <p>\n" +
                "            The beans are blooming, so robust,<br>\n" +
                "            Autoconfigure, in you we trust.<br>\n" +
                "            Controller, service, repository too,<br>\n" +
                "            They're all connected—just like glue!<br>\n" +
                "        </p>\n" +
                "        <p>\n" +
                "            <span class=\"highlight\">API calls flow</span> with every click,<br>\n" +
                "            As security layers do their trick.<br>\n" +
                "            Database queries, fast and keen,<br>\n" +
                "            With Spring Boot, we’re always seen.<br>\n" +
                "        </p>\n" +
                "    <\n";

    }
}
