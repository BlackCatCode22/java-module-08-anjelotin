package com.angelo.tuesDemo;

import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ChatBotService {

    private static final Logger logger = LoggerFactory.getLogger(ChatBotService.class);

    @Value("${openai.api.key}")
    private String openAiApiKey;

    private static final String OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";

    /**
     * Sends a message to OpenAI's API and retrieves a response.
     *
     * @param userMessage The message from the user.
     * @return The response from OpenAI.
     * @throws Exception If an error occurs during the API request.
     */
    public String getChatResponse(String userMessage) throws Exception {
        logger.info("Sending message to OpenAI: {}", userMessage);

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(OPENAI_API_URL);
            httpPost.setHeader("Authorization", "Bearer " + openAiApiKey);
            httpPost.setHeader("Content-Type", "application/json");

            // Prepare JSON request payload
            String requestBody = new ObjectMapper().writeValueAsString(createRequestBody(userMessage));
            httpPost.setEntity(new StringEntity(requestBody, ContentType.APPLICATION_JSON));

            try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                if (response.getCode() == 200) {
                    // Parse the response JSON
                    ObjectMapper objectMapper = new ObjectMapper();
                    JsonNode responseJson = objectMapper.readTree(response.getEntity().getContent());
                    String chatResponse = responseJson.at("/choices/0/message/content").asText();
                    logger.info("Received response from OpenAI: {}", chatResponse);
                    return chatResponse;
                } else {
                    String errorMessage = "Failed to get response from OpenAI: " + response.getReasonPhrase();
                    logger.error(errorMessage);
                    throw new RuntimeException(errorMessage);
                }
            }
        }
    }

    /**
     * Helper method to create the request body for the OpenAI API.
     *
     * @param userMessage The user message to include in the request.
     * @return The structured request body.
     */
    private Object createRequestBody(String userMessage) {
        return new Object() {
            public String model = "gpt-3.5-turbo";
            public Object[] messages = new Object[]{
                    new Object() {
                        public String role = "user";
                        public String content = userMessage;
                    }
            };
        };
    }
}
